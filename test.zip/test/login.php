<?php
$db='stiropor_drup998';
$hn='188.40.95.144';
$un='stiropor';
$pw='30oktobar';

?>