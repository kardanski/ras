<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Unos podataka</title>
<link rel="stylesheet" type="text/css" href="view.css" media="all">
<script type="text/javascript" src="view.js"></script>

</head>
<body id="main_body" >
	
	<img id="top" src="top.png" alt="">
	<div id="form_container">
	
		<h1><a>Unos podataka</a></h1>
		<br>
			<ul><label class="description" ><a href="form.php">Unos novih učenika</a><br>
			<a href="sviuneti.php">Pregledaj spisak unetih učenika</a><br>
			
			<a href="stampa.php">Štampanje podataka</a></label><br>
			
					<div class="form_description">
					    <br>
			<h2>Podaci su uneti.</h2>
			<br>
		</div>						
			<ul >
			    
	</div>
	<img id="bottom" src="bottom.png" alt="">
	</body>
</html>